package com.example.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMicroServicesCommunicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMicroServicesCommunicationApplication.class, args);
	}

}
